import cv2
import numpy as np
import serial
import serial.tools.list_ports
import time
from ultralytics import YOLO

# Auto-find Arduino
def find_arduino():
    for p in serial.tools.list_ports.comports():
        if "Arduino" in p.description or "CH340" in p.description:
            return p.device
    return None

port = find_arduino()
if not port:
    raise Exception("Arduino not found!")

ser = serial.Serial(port, 115200, timeout=1)
time.sleep(2)
print("Connected to Arduino on", port)

model = YOLO("C:/Users/vaibh/Downloads/Test2/Test2/best.pt")

# Servo bounds
X_MIN, X_MAX = 900, 2100
Y_MIN, Y_MAX = 900, 2100
X_HOME = 1500
Y_HOME = 1500

current_x = X_HOME
current_y = Y_HOME

def send(x, y, laser):
    x = int(np.clip(x, X_MIN, X_MAX))
    y = int(np.clip(y, Y_MIN, Y_MAX))
    ser.write(f"X{x} Y{y} L{1 if laser else 0}\n".encode())

send(X_HOME, Y_HOME, False)
time.sleep(2)

cap = cv2.VideoCapture(0)
w = int(cap.get(3))
h = int(cap.get(4))
cx, cy = w // 2, h // 2

# Tracking sensitivity tuning
GAIN_X = 0.18
GAIN_Y = 0.20
DEADZONE = 70
CONF_THRESHOLD = 0.50

search_direction = 1  # left/right
lost_frames = 0
LASER = False

print("Drone Tracking Ready — Press ESC to exit")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    results = model(frame, verbose=False)[0]

    detected = False
    best_area = 0

    for box in results.boxes:
        conf = box.conf.item()
        if conf < CONF_THRESHOLD:
            continue

        x1, y1, x2, y2 = map(int, box.xyxy[0])
        area = (x2 - x1) * (y2 - y1)

        if area > best_area:
            best_area = area
            obj_x = (x1 + x2) // 2
            obj_y = (y1 + y2) // 2
            detected = True

    if detected:
        lost_frames = 0
        LASER = True

        error_x = obj_x - cx
        error_y = obj_y - cy

        if abs(error_x) > DEADZONE:
            current_x -= error_x * GAIN_X
        if abs(error_y) > DEADZONE:
            current_y += error_y * GAIN_Y

        # Draw bounding box + marker
        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 3)
        cv2.circle(frame, (obj_x, obj_y), 8, (0, 255, 255), -1)
        cv2.putText(frame, "Drone", (x1, y1 - 10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        cv2.putText(frame, "TRACKING", (10, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

    else:
        LASER = False
        lost_frames += 1

        if lost_frames > 10:
            # Balanced vertical + horizontal scanning
            current_x += search_direction * 12

            if current_x >= X_MAX or current_x <= X_MIN:
                search_direction *= -1
                current_y += 28  # 🔹 Slightly slower vertical scanning → more stable detection

                if current_y >= Y_MAX or current_y <= Y_MIN:
                    current_y = Y_HOME

            cv2.putText(frame, "SCANNING...", (10, 40),
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

    send(current_x, current_y, LASER)

    cv2.drawMarker(frame, (cx, cy), (255, 255, 255),
                   cv2.MARKER_CROSS, 30, 2)
    cv2.imshow("Stabilized Drone Tracker", frame)

    if cv2.waitKey(1) == 27:
        break

send(X_HOME, Y_HOME, False)
cap.release()
cv2.destroyAllWindows()
ser.close()
print("Stopped safely")
